<template>
  <div class="myTrade info-bcg">거래했던 내역들</div>
</template>

<script>
export default {};
</script>

<style></style>
