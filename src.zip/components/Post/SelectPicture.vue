<template>
  <ul class="post-Picture">
    <li @change="handleFileUpload" v-if="device_info == 'web'">
      <label class="file_tab" for="postImageFileOpenInput" />
      <input
        type="file"
        id="postImageFileOpenInput"
        ref="uploadImageFile"
        accept="image/png, image/jpeg"
      />
    </li>
    <li v-else @click="handleFileUpload"></li>
    <li @click="submit_thumbnail(i)" v-for="(picture, i) in imageUrl" :key="i">
      <img class="post-imgs" :src="imageUrl[i] ? imageUrl[i] : null" />
    </li>
  </ul>
</template>

<script>
import { EventBus } from '@/utils/bus';
import { valideImageType, b64toBlob } from '@/utils/imgControl';
import { Plugins, CameraSource, CameraResultType } from '@capacitor/core';
import axios from 'axios';
const { Camera } = Plugins;
const { Device } = Plugins;

export default {
  name: 'post-picture',
  data() {
    return {
      uploadImageFile: '',
      imageUrl: [],
      blobs: [],
      formData: null,
      device_info: null,
    };
  },
  async mounted() {
    this.formData = new FormData();
    const { platform } = await Device.getInfo();
    this.device_info = platform;
  },
  created() {
    EventBus.$on('send_imgs', async bo_id => {
      await this.image_submit(bo_id);
      this.init_post();
    });

    EventBus.$on('post_init', res => {
      this.init_post();
    });

    EventBus.$on('update_imgs', async imgs => {
      console.log('이미지 버스 도착!');
      this.imageUrl = [];
      this.blobs = [];
      await imgs.forEach(async (v, index) => {
        this.imageUrl.push(v.im_location);
        await this.toDataUrl(v.im_location, this.blobs, b64toBlob);
      });
    });
  },
  beforeDestroy() {
    EventBus.$off('send_imgs');
    EventBus.$off('update_imgs');
    EventBus.$off('post_init');
  },
  methods: {
    async handleFileUpload() {
      // DeviceInfo 보고 사용자 구분하기
      if (this.device_info != 'web') {
        try {
          const image = await Camera.getPhoto({
            quality: 100,
            allowEditing: false,
            resultType: CameraResultType.DataUrl,
            source: CameraSource.Prompt,
            promptLabelPhoto: '앨범에서 가져오기',
            promptLabelPicture: '직접촬영',
          });

          // 이미지파일 dataUrl 저장
          let dataUrl = image.dataUrl;
          this.imageUrl.push(dataUrl);

          let block = dataUrl.split(';');
          let contentType = block[0].split(':')[1]; // In this case "image/gif"
          let realData = block[1].split(',')[1]; // In this case "iVBORw0KGg...."
          let blob = b64toBlob(realData, contentType);

          console.log('this.blobs: ', this.blobs);
          // 생성된 blob 객체 배열 저장
          this.blobs.push(blob);
        } catch (err) {
          console.log('err', err);
        }
      } else {
        const image = this.$refs.uploadImageFile.files[0];
        if (!valideImageType(image)) return;

        let reader = new FileReader();
        /* reader 시작시 함수 구현 */
        reader.onload = e => {
          this.imageUrl.push(e.target.result);
        };
        reader.readAsDataURL(image);
        this.blobs.push(image);
      }
    },
    async image_submit(bo_id) {
      await this.blobs.forEach((item, index) => {
        this.formData.append('img', item);
      });
      console.log(this.formData);
      try {
        console.log('마지막 this.blobs: ', this.blobs);
        const req = new XMLHttpRequest();
        req.open('POST', 'https://server.anicro.org/board/image', true);
        req.setRequestHeader('bo_id', bo_id);
        req.send(this.formData);
      } catch (error) {
        alert(error);
      }
    },
    deleteUrl(index_number) {
      this.imageUrl.splice(index_number, 1);
      this.blobs.splice(index_number, 1);
    },
    init_post() {
      this.imageUrl = [];
      this.blobs = [];
      this.formData = new FormData();
    },
    async toDataUrl(url, array, b64toBlob) {
      axios
        .get(url, {
          responseType: 'blob',
          crossDomain: true,
          headers: {
            'Access-Control-Allow-Origin': '*',
          },
        })
        .then(function(response) {
          const reader = new window.FileReader();
          reader.readAsDataURL(response.data);
          reader.onload = async function() {
            let dataUrl = await reader.result;
            let block = dataUrl.split(';');
            let contentType = block[0].split(':')[1]; // In this case "image/gif"
            let realData = block[1].split(',')[1]; // In this case "iVBORw0KGg...."
            let result = await b64toBlob(realData, contentType);
            array.push(result);
          };
        });
    },
    submit_thumbnail(index_number) {
      console.log(index_number);
      if (this.imageUrl.length == 0) EventBus.$emit('thumbnail_change', 5);
      else EventBus.$emit('thumbnail_change', index_number);
      // const all_of_li = document.querySelector(
      //   `.post-Picture li:nth-child(2n+1)`,
      // );
      // const selected_li = document.querySelector(
      //   `.post-Picture > li:nth-child(n + ${index_number})`,
      // );
      // all_of_li.style.border = '2px solid rgb(66, 66, 66)';
      // selected_li.style.border = '2px solid rgb(236, 75, 0)';
    },
  },
};
</script>

<style></style>
