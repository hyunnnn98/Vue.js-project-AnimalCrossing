<template>
  <div class="Notice"></div>
</template>

<script>
export default {};
</script>

<style>
.Notice {
  border-bottom: 1px solid #e0e0e0;
  background-image: url('../../imgs/logo.jpg');
  background-size: cover;
  background-repeat: no-repeat;
  margin-top: 2em;
  height: 200px;
  /* opacity: 0.7; */
}
</style>
