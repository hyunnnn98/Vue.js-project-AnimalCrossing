<template>
  <ion-content>
    <UserFind></UserFind>
  </ion-content>
</template>

<script>
import UserFind from '@/components/User/UserFind';
export default {
  components: {
    UserFind,
  },
};
</script>

<style>
@import url('../css/USER.css');
</style>
