module.exports = {
  devServer: {
    overlay: false,
  },
};
